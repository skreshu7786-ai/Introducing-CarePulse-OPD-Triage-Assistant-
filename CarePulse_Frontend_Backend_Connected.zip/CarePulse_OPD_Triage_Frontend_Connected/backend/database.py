"""Database configuration for CarePulse OPD Triage Assistant."""
import os
from pathlib import Path
from dotenv import load_dotenv
from sqlalchemy import create_engine, text
from sqlalchemy.engine import URL

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env", override=False)

DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = int(os.getenv("DB_PORT", "5432"))
DB_NAME = os.getenv("DB_NAME", "opd_triage_db")
DB_USER = os.getenv("DB_USER", "postgres")
DB_PASSWORD = os.getenv("DB_PASSWORD")

if not DB_PASSWORD:
    raise RuntimeError(f"DB_PASSWORD is missing. Create {BASE_DIR / '.env'}")

DATABASE_URL = URL.create(
    "postgresql+psycopg", username=DB_USER, password=DB_PASSWORD,
    host=DB_HOST, port=DB_PORT, database=DB_NAME
)
engine = create_engine(DATABASE_URL, pool_pre_ping=True, future=True)

def check_database_connection() -> bool:
    """Return True when PostgreSQL accepts a simple query; raise on failure."""
    with engine.connect() as connection:
        connection.execute(text("SELECT 1"))
    return True
