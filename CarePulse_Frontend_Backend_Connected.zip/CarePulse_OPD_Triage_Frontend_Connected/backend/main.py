"""CarePulse API. Existing PostgreSQL tables are used; this app does not create them."""
from datetime import datetime, timezone
from typing import Optional, List, Any
import secrets
import string

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, ConfigDict
from sqlalchemy import MetaData, Table, select, insert, update, desc, func
from sqlalchemy.exc import IntegrityError, SQLAlchemyError

from database import engine

app = FastAPI(title="CarePulse OPD Triage API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://127.0.0.1:5500", "http://localhost:5500",
        "http://127.0.0.1:5501", "http://localhost:5501",
        "http://127.0.0.1:3000", "http://localhost:3000",
    ],
    allow_credentials=False, allow_methods=["*"], allow_headers=["*"],
)

metadata = MetaData()
patients: Table
vitals: Table
assessments: Table
history: Table
users: Table

@app.on_event("startup")
def reflect_existing_tables():
    global patients, vitals, assessments, history, users
    try:
        metadata.reflect(bind=engine, only=["patients", "vital_signs", "triage_assessments", "patient_history", "users"])
        patients = metadata.tables["patients"]
        vitals = metadata.tables["vital_signs"]
        assessments = metadata.tables["triage_assessments"]
        history = metadata.tables["patient_history"]
        users = metadata.tables["users"]
    except Exception as exc:
        raise RuntimeError("Could not read expected tables from database 'opd_triage_db'. Check DB_NAME and run your SQL creation script first.") from exc

class TriageInput(BaseModel):
    model_config = ConfigDict(extra="ignore")
    patient_id: str = Field(min_length=1, max_length=50)
    name: Optional[str] = Field(default=None, max_length=150)
    age: int = Field(ge=0, le=120)
    sex: Optional[str] = "Unknown"
    language: Optional[str] = None
    chief_complaint: str = Field(min_length=1)
    duration: Optional[str] = None
    known_conditions: Optional[str] = None
    medications: Optional[str] = None
    bp_systolic: Optional[int] = Field(default=None, ge=40, le=300)
    bp_diastolic: Optional[int] = Field(default=None, ge=20, le=200)
    pulse: Optional[int] = Field(default=None, ge=1, le=300)
    temperature: Optional[float] = Field(default=None, ge=25, le=45)
    spo2: Optional[int] = Field(default=None, ge=0, le=100)
    respiratory_rate: Optional[int] = Field(default=None, ge=1, le=100)
    red_flags: List[str] = []

class ReviewInput(BaseModel):
    reviewed_by: Optional[int] = None
    clinical_notes: Optional[str] = None

@app.get("/")
def root():
    return {"name": "CarePulse OPD Triage API", "docs": "/docs", "health": "/health"}

@app.get("/health")
def health():
    try:
        with engine.connect() as conn:
            conn.exec_driver_sql("SELECT 1")
        return {"status": "ok", "database": "connected", "db_name": "opd_triage_db"}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Database connection failed: {exc}")

def patient_dict(row: dict, vital: Optional[dict] = None, assessment: Optional[dict] = None):
    a = assessment or {}
    v = vital or {}
    flags = a.get("red_flags") or []
    return {
        "patient_id": row.get("patient_code"), "name": row.get("full_name"), "age": row.get("age"),
        "sex": row.get("sex"), "language": row.get("language"), "chief_complaint": row.get("chief_complaint"),
        "duration": row.get("symptom_duration"), "known_conditions": row.get("known_conditions"),
        "medications": row.get("medications"), "bp_systolic": v.get("systolic_bp"),
        "bp_diastolic": v.get("diastolic_bp"), "pulse": v.get("pulse"), "temperature": float(v["temperature"]) if v.get("temperature") is not None else None,
        "spo2": v.get("spo2"), "respiratory_rate": v.get("respiratory_rate"), "red_flags": flags,
        "status": "Reviewed" if a.get("reviewed_at") else "Pending clinical review",
        "triage_level": a.get("triage_level"), "suggested_department": a.get("suggested_department"),
        "emergency_flag": a.get("emergency_flag", False), "clinical_notes": a.get("clinical_notes"),
        "created_at": row.get("created_at").isoformat() if row.get("created_at") else None,
    }

def load_records(search: Optional[str] = None):
    with engine.connect() as conn:
        stmt = select(patients).order_by(desc(patients.c.created_at))
        if search:
            stmt = stmt.where(patients.c.patient_code.ilike(f"%{search}%") | patients.c.chief_complaint.ilike(f"%{search}%"))
        rows = [dict(r._mapping) for r in conn.execute(stmt)]
        result = []
        for row in rows:
            vstmt = select(vitals).where(vitals.c.patient_id == row["id"]).order_by(desc(vitals.c.measured_at)).limit(1)
            astmt = select(assessments).where(assessments.c.patient_id == row["id"]).order_by(desc(assessments.c.created_at)).limit(1)
            vrow = conn.execute(vstmt).first(); arow = conn.execute(astmt).first()
            result.append(patient_dict(row, dict(vrow._mapping) if vrow else None, dict(arow._mapping) if arow else None))
        return result

@app.get("/api/patients")
def get_patients(search: Optional[str] = Query(default=None)):
    try: return load_records(search)
    except SQLAlchemyError as exc: raise HTTPException(500, detail=f"Could not load patients: {exc}")

@app.get("/api/patients/{patient_code}")
def get_patient(patient_code: str):
    records = load_records(patient_code)
    record = next((r for r in records if r["patient_id"] == patient_code), None)
    if not record: raise HTTPException(404, "Patient not found")
    return record

@app.post("/api/triage", status_code=201)
def submit_triage(payload: TriageInput):
    try:
        with engine.begin() as conn:
            existing = conn.execute(select(patients.c.id).where(patients.c.patient_code == payload.patient_id)).first()
            if existing: raise HTTPException(409, detail="That patient ID already exists in the database.")
            pdata = {
                "patient_code": payload.patient_id, "full_name": payload.name or "Demo patient", "age": payload.age,
                "sex": payload.sex or "Unknown", "language": payload.language, "chief_complaint": payload.chief_complaint,
                "symptom_duration": payload.duration, "known_conditions": payload.known_conditions, "medications": payload.medications,
            }
            pid = conn.execute(insert(patients).values(**pdata).returning(patients.c.id)).scalar_one()
            vdata = {"patient_id": pid, "systolic_bp": payload.bp_systolic, "diastolic_bp": payload.bp_diastolic,
                     "pulse": payload.pulse, "temperature": payload.temperature, "spo2": payload.spo2,
                     "respiratory_rate": payload.respiratory_rate}
            if any(v is not None for k, v in vdata.items() if k != "patient_id"):
                conn.execute(insert(vitals).values(**vdata))
            conn.execute(insert(assessments).values(patient_id=pid, triage_level=None,
                suggested_department=None, emergency_flag=bool(payload.red_flags), red_flags=payload.red_flags,
                assessment_source="pending", clinical_notes="Requires qualified clinician review."))
            conn.execute(insert(history).values(patient_id=pid, event_type="intake_created",
                event_description="Patient intake submitted; awaiting clinician review.", performed_by=None))
        return {"success": True, "patient_id": payload.patient_id, "message": "Patient intake saved to PostgreSQL; clinician review required."}
    except HTTPException: raise
    except IntegrityError as exc: raise HTTPException(409, detail=f"Database constraint error: {exc.orig}")
    except SQLAlchemyError as exc: raise HTTPException(500, detail=f"Could not save patient: {exc}")

@app.post("/api/patients/{patient_code}/review")
def mark_reviewed(patient_code: str, payload: ReviewInput = ReviewInput()):
    with engine.begin() as conn:
        row = conn.execute(select(patients.c.id).where(patients.c.patient_code == patient_code)).first()
        if not row: raise HTTPException(404, "Patient not found")
        pid = row[0]
        assessment = conn.execute(select(assessments.c.id).where(assessments.c.patient_id == pid).order_by(desc(assessments.c.created_at)).limit(1)).first()
        if not assessment: raise HTTPException(404, "Triage assessment not found")
        values = {"reviewed_at": datetime.now(timezone.utc), "clinical_notes": payload.clinical_notes}
        if payload.reviewed_by is not None: values["reviewed_by"] = payload.reviewed_by
        conn.execute(update(assessments).where(assessments.c.id == assessment[0]).values(**values))
        conn.execute(insert(history).values(patient_id=pid, event_type="reviewed", event_description="Intake marked reviewed.", performed_by=payload.reviewed_by))
    return {"success": True, "patient_id": patient_code, "status": "Reviewed"}

@app.get("/api/patient-history")
def get_patient_history():
    # Returns a flat list compatible with the frontend's patient-oriented history display.
    return load_records()

@app.get("/api/dashboard-summary")
def dashboard_summary():
    records = load_records()
    return {"total_patients": len(records), "pending_patients": sum(r["status"] != "Reviewed" for r in records),
            "alert_patients": sum(bool(r["red_flags"]) for r in records), "reviewed_patients": sum(r["status"] == "Reviewed" for r in records)}
