# CarePulse backend

## Database
This backend uses the existing PostgreSQL database `opd_triage_db` and the five existing tables. It does not create or modify your tables.

1. Copy `.env.example` to `.env` in this `backend` folder.
2. Set `DB_PASSWORD` to your PostgreSQL password. Confirm `DB_NAME=opd_triage_db` exactly matches the database in pgAdmin.
3. In Command Prompt, from this backend folder:

```bat
python -m venv venv
venv\Scripts\activate
python -m pip install -r requirements.txt
python test_db.py
python -m uvicorn main:app --reload
```

Open `http://127.0.0.1:8000/health` and `http://127.0.0.1:8000/docs`.

## Existing frontend note
The frontend files from the uploaded ZIP are included unchanged. Its current dashboard, history, and result scripts use browser `localStorage`; the patient form also attempts `window.CarePulseAPI.submitPatientToBackend`, but the provided `api.js` does not define that global object. Therefore the API/backend is ready, but the unchanged frontend will not fully display database records until its JavaScript is connected to these endpoints. As requested, no frontend files were modified in this package.

This is an educational prototype, not a validated clinical triage system. Do not use it for autonomous clinical decisions or real patient care without appropriate clinical, security, and privacy review.
