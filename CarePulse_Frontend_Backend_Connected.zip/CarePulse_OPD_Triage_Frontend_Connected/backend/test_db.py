from database import check_database_connection

if __name__ == "__main__":
    try:
        check_database_connection()
        print("Database connection successful!")
    except Exception as exc:
        print("Database connection failed:", exc)
        raise SystemExit(1)
