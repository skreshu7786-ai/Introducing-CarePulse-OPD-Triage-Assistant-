const container = document.getElementById("resultContainer");
function showField(label, value) { const p = document.createElement("p"); const strong = document.createElement("strong"); strong.textContent = `${label}: `; p.append(strong, document.createTextNode(value || "Not recorded")); return p; }
async function renderResult() {
  if (!container) return;
  const params = new URLSearchParams(location.search);
  const last = JSON.parse(sessionStorage.getItem("carepulse_last_result") || "null");
  const id = params.get("id") || last?.patient?.patient_id;
  if (!id) { container.textContent = "Record not found. Return to the dashboard and select a patient."; return; }
  container.replaceChildren(); const loading = document.createElement("p"); loading.textContent = "Loading patient record..."; container.appendChild(loading);
  try {
    const patient = await window.CarePulseAPI.getPatient(id);
    container.replaceChildren(); const title = document.createElement("h2"); title.textContent = `Patient ${patient.patient_id}`; container.appendChild(title);
    const notice = document.createElement("div"); notice.className = "notice alert-notice"; notice.textContent = "Prototype only: no validated triage level has been calculated. A qualified clinician must assess the patient."; container.appendChild(notice);
    [ ["Name", patient.name], ["Age", patient.age], ["Sex", patient.sex], ["Chief complaint", patient.chief_complaint], ["Symptom duration", patient.duration], ["Language", patient.language], ["Blood pressure", patient.bp_systolic != null && patient.bp_diastolic != null ? `${patient.bp_systolic}/${patient.bp_diastolic} mmHg` : "Not recorded"], ["Pulse", patient.pulse != null ? `${patient.pulse} beats/min` : "Not recorded"], ["Temperature", patient.temperature != null ? `${patient.temperature} °C` : "Not recorded"], ["SpO₂", patient.spo2 != null ? `${patient.spo2}%` : "Not recorded"], ["Respiratory rate", patient.respiratory_rate ?? "Not recorded"], ["Known conditions", patient.known_conditions], ["Medications", patient.medications], ["Reported safety flags", (patient.red_flags || []).join(", ") || "None selected"], ["Review status", patient.status], ["Clinical notes", patient.clinical_notes] ].forEach(([label, value]) => container.appendChild(showField(label, String(value ?? ""))));
    if (patient.status !== "Reviewed") {
      const button = document.createElement("button"); button.className = "button button-primary"; button.textContent = "Mark reviewed";
      button.addEventListener("click", async () => { button.disabled = true; button.textContent = "Saving..."; try { await window.CarePulseAPI.markPatientReviewed(patient.patient_id); await renderResult(); } catch (error) { button.disabled = false; button.textContent = "Mark reviewed"; window.alert(`Could not update review status: ${error.message}`); } }); container.appendChild(button);
    }
  } catch (error) { container.replaceChildren(); const p = document.createElement("p"); p.textContent = `Could not load patient record: ${error.message}. Confirm the backend is running.`; container.appendChild(p); }
}
renderResult();
