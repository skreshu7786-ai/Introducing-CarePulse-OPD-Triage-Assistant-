const patientForm = document.getElementById("patientForm");

if (patientForm) {
  const progress = document.getElementById("formProgress");
  const message = document.getElementById("formMessage");
  const submitButton = patientForm.querySelector('button[type="submit"], input[type="submit"]');

  function updateProgress() {
    const fields = [...patientForm.querySelectorAll("input[required], textarea[required], select[required]")];
    const completed = fields.filter(field => String(field.value || "").trim() && field.checkValidity()).length;
    if (progress) progress.style.width = `${fields.length ? completed / fields.length * 100 : 0}%`;
  }
  function showMessage(text, isError = true) {
    if (!message) { window.alert(text); return; }
    message.hidden = false;
    message.textContent = text;
    message.classList.toggle("error", isError);
    message.classList.toggle("success", !isError);
  }

  patientForm.addEventListener("input", updateProgress);
  patientForm.addEventListener("reset", () => setTimeout(updateProgress, 0));
  patientForm.addEventListener("submit", async event => {
    event.preventDefault();
    if (!patientForm.reportValidity()) return;
    const data = new FormData(patientForm);
    const patient = {
      patient_id: String(data.get("patientId") || "").trim(),
      name: String(data.get("patientName") || "").trim() || null,
      age: Number(data.get("age")), sex: data.get("sex") || "Unknown",
      bp_systolic: data.get("bpSystolic") ? Number(data.get("bpSystolic")) : null,
      bp_diastolic: data.get("bpDiastolic") ? Number(data.get("bpDiastolic")) : null,
      pulse: data.get("pulse") ? Number(data.get("pulse")) : null,
      temperature: data.get("temperature") ? Number(data.get("temperature")) : null,
      spo2: data.get("spo2") ? Number(data.get("spo2")) : null,
      respiratory_rate: data.get("respiratoryRate") ? Number(data.get("respiratoryRate")) : null,
      chief_complaint: String(data.get("complaint") || "").trim(),
      language: data.get("language") || null,
      duration: data.get("duration") || null,
      known_conditions: String(data.get("conditions") || "").trim() || null,
      medications: String(data.get("medications") || "").trim() || null,
      red_flags: data.getAll("redFlags")
    };

    if (message) { message.hidden = true; message.textContent = ""; }
    if (submitButton) { submitButton.disabled = true; submitButton.dataset.originalText = submitButton.textContent; submitButton.textContent = "Saving..."; }
    try {
      const result = await window.CarePulseAPI.submitPatientToBackend(patient);
      sessionStorage.setItem("carepulse_last_result", JSON.stringify({ patient, backend_response: result }));
      window.location.href = `triage-result.html?id=${encodeURIComponent(patient.patient_id)}`;
    } catch (error) {
      showMessage(`Could not save patient to the database: ${error.message}. Check that the backend is running, then try again.`);
    } finally {
      if (submitButton) { submitButton.disabled = false; submitButton.textContent = submitButton.dataset.originalText || "Submit"; }
    }
  });
  updateProgress();
}
