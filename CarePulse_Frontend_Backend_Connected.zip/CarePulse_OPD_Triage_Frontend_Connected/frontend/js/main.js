document.addEventListener("DOMContentLoaded", async () => {
  try {
    const summary = await window.CarePulseAPI.getDashboardSummary();
    const counts = { totalPatients: summary.total_patients, pendingPatients: summary.pending_patients, alertPatients: summary.alert_patients, reviewedPatients: summary.reviewed_patients };
    Object.entries(counts).forEach(([id, count]) => { const element = document.getElementById(id); if (element) element.textContent = count; });
  } catch (error) {
    console.error("Could not load CarePulse summary from backend:", error);
  }
});
