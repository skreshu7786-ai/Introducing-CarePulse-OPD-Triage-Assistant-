let dashboardPatients = [];
function renderDashboard() {
  const body = document.getElementById("patientTableBody");
  if (!body) return;
  const search = (document.getElementById("patientSearch")?.value || "").toLowerCase();
  const status = document.getElementById("statusFilter")?.value || "all";
  const filtered = dashboardPatients.filter(p => {
    const matchesSearch = `${p.patient_id || ""} ${p.chief_complaint || ""} ${p.name || ""}`.toLowerCase().includes(search);
    return matchesSearch && (status === "all" || p.status === status);
  });
  body.replaceChildren();
  filtered.forEach(patient => {
    const tr = document.createElement("tr");
    const flagged = (patient.red_flags || []).length > 0;
    [patient.patient_id, patient.age, patient.chief_complaint, flagged ? "Needs review" : "Not flagged", patient.status].forEach((value, index) => {
      const td = document.createElement("td");
      if (index === 3) { const badge = document.createElement("span"); badge.className = `badge ${flagged ? "badge-danger" : ""}`; badge.textContent = value; td.appendChild(badge); }
      else td.textContent = value ?? "Not recorded";
      tr.appendChild(td);
    });
    const actionCell = document.createElement("td"); const link = document.createElement("a");
    link.className = "button button-outline"; link.href = `triage-result.html?id=${encodeURIComponent(patient.patient_id)}`; link.textContent = "Review";
    actionCell.appendChild(link); tr.appendChild(actionCell); body.appendChild(tr);
  });
  const empty = document.getElementById("emptyState"); if (empty) empty.hidden = filtered.length !== 0;
  const pending = dashboardPatients.filter(p => p.status !== "Reviewed").length;
  const alerts = dashboardPatients.filter(p => (p.red_flags || []).length > 0).length;
  const reviewed = dashboardPatients.length - pending;
  const setText = (id, value) => { const el = document.getElementById(id); if (el) el.textContent = value; };
  setText("totalPatients", dashboardPatients.length); setText("pendingPatients", pending); setText("alertPatients", alerts); setText("reviewedPatients", reviewed);
  const alert = document.getElementById("dashboardAlert");
  if (alert) { alert.hidden = alerts === 0; alert.textContent = alerts ? `${alerts} record(s) contain reported safety flags. Ensure prompt clinical review under your approved protocol.` : ""; }
}
async function refreshDashboard() {
  const body = document.getElementById("patientTableBody");
  try { dashboardPatients = await window.CarePulseAPI.getPatients(); renderDashboard(); }
  catch (error) { if (body) { body.replaceChildren(); const tr = document.createElement("tr"); const td = document.createElement("td"); td.colSpan = 6; td.textContent = `Could not load patients: ${error.message}. Confirm the backend is running at ${API_BASE_URL}.`; tr.appendChild(td); body.appendChild(tr); } }
}
document.getElementById("patientSearch")?.addEventListener("input", renderDashboard);
document.getElementById("statusFilter")?.addEventListener("change", renderDashboard);
refreshDashboard();
