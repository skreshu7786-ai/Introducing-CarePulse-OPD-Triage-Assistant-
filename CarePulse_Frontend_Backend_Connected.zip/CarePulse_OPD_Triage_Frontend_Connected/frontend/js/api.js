// Shared API client for the CarePulse frontend. The UI/CSS is unchanged.
const API_BASE_URL = window.CAREPULSE_API_BASE_URL || "http://127.0.0.1:8000";

async function apiRequest(path, options = {}) {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers: { ...(options.body ? { "Content-Type": "application/json" } : {}), ...(options.headers || {}) }
  });
  const text = await response.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!response.ok) {
    const detail = data && typeof data === "object" ? (data.detail || data.message) : data;
    throw new Error(detail || `API request failed (${response.status})`);
  }
  return data;
}

async function getPatients(search = "") {
  const query = search ? `?search=${encodeURIComponent(search)}` : "";
  return apiRequest(`/api/patients${query}`);
}

async function getPatient(patientId) {
  return apiRequest(`/api/patients/${encodeURIComponent(patientId)}`);
}

async function submitPatient(patient) {
  return apiRequest("/api/triage", { method: "POST", body: JSON.stringify(patient) });
}

async function markPatientReviewed(patientId, clinicalNotes = null) {
  return apiRequest(`/api/patients/${encodeURIComponent(patientId)}/review`, {
    method: "POST", body: JSON.stringify({ clinical_notes: clinicalNotes })
  });
}

async function getDashboardSummary() {
  return apiRequest("/api/dashboard-summary");
}

// Backwards-compatible name used by the original patient form script.
window.CarePulseAPI = {
  getPatients, getPatient, submitPatient, submitPatientToBackend: submitPatient,
  markPatientReviewed, getDashboardSummary
};
