const historyBody = document.getElementById("historyBody");
let historyRecords = [];
function renderHistory() {
  if (!historyBody) return;
  const query = (document.getElementById("historySearch")?.value || "").toLowerCase();
  const matches = historyRecords.filter(p => `${p.patient_id || ""} ${p.chief_complaint || ""} ${p.name || ""}`.toLowerCase().includes(query));
  historyBody.replaceChildren();
  matches.forEach(p => {
    const tr = document.createElement("tr");
    [p.patient_id, p.age, p.chief_complaint, p.created_at ? new Date(p.created_at).toLocaleString() : "Unknown", p.status].forEach(value => { const td = document.createElement("td"); td.textContent = value ?? "Not recorded"; tr.appendChild(td); });
    const td = document.createElement("td"); const a = document.createElement("a"); a.className = "button button-outline"; a.href = `triage-result.html?id=${encodeURIComponent(p.patient_id)}`; a.textContent = "Open"; td.appendChild(a); tr.appendChild(td); historyBody.appendChild(tr);
  });
  const empty = document.getElementById("historyEmpty"); if (empty) empty.hidden = matches.length !== 0;
}
async function loadHistory() {
  try { historyRecords = await window.CarePulseAPI.getPatients(); renderHistory(); }
  catch (error) { if (historyBody) { historyBody.replaceChildren(); const tr = document.createElement("tr"); const td = document.createElement("td"); td.colSpan = 6; td.textContent = `Could not load patient history: ${error.message}. Check that the backend is running.`; tr.appendChild(td); historyBody.appendChild(tr); } }
}
document.getElementById("historySearch")?.addEventListener("input", renderHistory);
document.getElementById("exportHistory")?.addEventListener("click", () => {
  const headers = ["patient_id", "name", "age", "sex", "chief_complaint", "status", "created_at"];
  const escapeCSV = value => `"${String(value ?? "").replace(/"/g, '""')}"`;
  const csv = [headers.join(","), ...historyRecords.map(record => headers.map(h => escapeCSV(record[h])).join(","))].join("\r\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" }); const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = "carepulse-patient-history.csv"; a.click(); URL.revokeObjectURL(url);
});
loadHistory();
