# CarePulse OPD Triage Assistant — frontend connected to FastAPI/PostgreSQL

The existing HTML layout and CSS files are preserved. The frontend JavaScript now reads/writes records through the FastAPI backend instead of relying on localStorage for patient records.

## 1. Configure the backend

Open `backend/.env.example`, copy it to `backend/.env`, and set your PostgreSQL credentials. The expected database name is `opd_triage_db` (matching the SQL script you provided):

```dotenv
DB_HOST=localhost
DB_PORT=5432
DB_NAME=opd_triage_db
DB_USER=postgres
DB_PASSWORD=YOUR_POSTGRES_PASSWORD
```

Do not share `.env` or commit it to source control.

## 2. Start the backend

In a terminal:

```bat
cd backend
python -m venv venv
venv\Scripts\activate
python -m pip install -r requirements.txt
python test_db.py
python -m uvicorn main:app --reload
```

Open `http://127.0.0.1:8000/health` and `http://127.0.0.1:8000/docs`.

## 3. Serve the frontend

In VS Code, open the `frontend` folder with Live Server. Port 5500 is allowed by the backend CORS settings. Open the homepage and test Register Patient, Dashboard, Patient History, and Mark reviewed.

Do not open pages as `file://`; use Live Server or another local HTTP server.

## API-connected behaviors

- Homepage metrics: `GET /api/dashboard-summary`
- Dashboard and history: `GET /api/patients`
- Registration: `POST /api/triage`
- Detail: `GET /api/patients/{patient_code}`
- Review status: `POST /api/patients/{patient_code}/review`
- CSV export exports records fetched from the API.

## Important

The API reflects your existing tables and does not create or alter them. Ensure the SQL script has been run in `opd_triage_db`. This prototype does not calculate a validated triage score; clinical review is required. Review endpoints are not authenticated and this should not be used with real patient data in production without security and clinical validation.
