INSERT INTO public.patient_history(
	id, patient_id, event_type, event_description, performed_by, created_at)
	VALUES (?, ?, ?, ?, ?, ?);